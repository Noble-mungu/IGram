$(document).ready(()=>{
    $('#upload-image').click(()=>{
        $('#upload').trigger('click')
    })
})