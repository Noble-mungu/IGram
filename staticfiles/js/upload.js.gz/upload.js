$(document).ready(()=>{
    $('#upload-btn').click(()=>{
        $('#upload').trigger('click')
    })
})
